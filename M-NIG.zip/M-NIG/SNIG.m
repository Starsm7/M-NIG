clear;
clc;


load('C:\02\data.mat');
data=zscore(data);
for i=1:23
reference(:,i)=[data(1:901,i);data(905:964,i);data(968:1151,i);data(1153:2116,i)];%ȥ����������
end
% ���������ݴ洢��processSO2��
  processSO1 = [];
  count = 1;
  % ��־processSO2�еĵ�ǰ�洢����
  processSO1Row =1;
  % �����ĳ�ʼλ�á�����λ��
  slideWindowStart = 0;
  slideWindowEnd = 0;
  % ���ڳߴ�
  step = 10;
  [avgSO1r,avgSO1c] = size(reference);
  for r = 1:avgSO1r %�����ò���
    slideWindowStart = r;
    slideWindowEnd = slideWindowStart + step - 1;
    if slideWindowEnd == avgSO1r
        for eachStep = slideWindowStart:avgSO1r
            processSO1(processSO1Row,count,1:23) = reference(eachStep,1:23);
            count = count + 1;
        end
        break;
    end
     for eachStep = slideWindowStart:slideWindowEnd
        processSO1(processSO1Row,count,1:23) = data(eachStep,1:23);
        count = count + 1;
     end
   
     processSO1Row = processSO1Row + 1;%��ǰ�洢������
     count = 1;
  end
%case����
  % ���������ݴ洢��processSO2��
  processSO2 = [];
  count = 1;
  % ��־processSO2�еĵ�ǰ�洢����
  processSO2Row =1;
  % �����ĳ�ʼλ�á�����λ��
  slideWindowStart = 0;
  slideWindowEnd = 0;
  % ���ڳߴ�
  step = 10;
  [avgSO2r,avgSO2c] = size(data);
  for r = 1:avgSO2r %�����ò���
    slideWindowStart = r;
    slideWindowEnd = slideWindowStart + step - 1;
    if slideWindowEnd == avgSO2r
        for eachStep = slideWindowStart:avgSO2r
            processSO2(processSO2Row,count,1:23) = data(eachStep,1:23);
            count = count + 1;
        end
        break;
    end
     for eachStep = slideWindowStart:slideWindowEnd
        processSO2(processSO2Row,count,1:23) = data(eachStep,1:23);
        count = count + 1;
     end
   
     processSO2Row = processSO2Row + 1;%��ǰ�洢������
     count = 1;
  end
cdata=permute(processSO2,[1 3 2]) ;
rdata=permute(processSO1,[1 3 2]) ;
ppsize=size(cdata);%case
psize=size(rdata);
fid1=fopen('C:\con_edge.txt');
control_network={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    control_network{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
total_node_num=j;
%% ��ȡȨ���ļ�
fid1=fopen('C:\con_weight.txt');
control_weight={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    control_weight{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
p_joint=[];
weight_sum=zeros(23,1);
for na=1:length(control_weight)
  legt_wegt(na)=length(control_weight{na});
end
%% ���ϸ���a=reshape(control_weight{1},legt_wegt(1),1)b=char(a); c=str2num(b)
for na=1:total_node_num%23
        weight_sum(na)=weight_sum(na)+sum(str2num(char(reshape(control_weight{na},legt_wegt(na),1))))-na;
     for n=2:length(control_network{na})
        p_joint(na,n-1)=(str2num(control_weight{na}{n-1}))./weight_sum(na); 
     end
end
% psize_=size(p_cond_);
% for i=1:psize_(1)
%     for j=1:psize_(2)
%     p_cond(i,j)=p_cond_(i,j)./sum(p_cond_(i,:));
%     end
% end
for m=1:ppsize(1)
for na=1:total_node_num
    for n=2:length(control_network{na})-1%2:6
        center=control_network{na}{1};
        center=str2num(center);
        nei=control_network{na}{n};
        ne=str2num(nei);
      for j=1:ppsize(3) %10
         p_dis(m,na,j)=(abs(sum(abs(cdata(m,center,j)-cdata(m,n-1,j))))).^(1/2);
         %p_dis(n-1,j)=p_dis(n-1,j)./sum(p_dis(n-1,:));
      end
    end
end
end
%a=p_dis(:,:,1);
p_dis=abs(zscore(log(1.5+p_dis)));
entropy_node=zeros(ppsize(1),ppsize(2));
%entropy_node=permute(entropy_node,[1 3 2]) ;
for m=1:ppsize(1)
for na=1:total_node_num
     for j=1:ppsize(3)
     p_node(m,na,j)=p_dis(m,na,j)./sum(p_dis(m,na,:)); 
     entropy_node(m,na)=entropy_node(m,na)-p_node(m,na,j).*cdata(m,na,j).*log(abs(cdata(m,na,j).*p_node(m,na,j)));%�ڵ���������
end
end
end
max_legt_wegt=max(legt_wegt);
p_cond=zeros(total_node_num,5);
ES_node=zeros(ppsize(1),ppsize(2));
for m=1:ppsize(1)
for na=1:total_node_num
    for n=2:length(control_network{na})-1%5a=length(control_network{1})
        center=control_network{na}{1};
        center=str2num(center);
        nei=control_network{na}{n};
        ne=str2num(nei);
      for j=1:ppsize(3) %10    
    
         p_cond(na,n-1)=p_joint(na,n-1)./p_node(na,j);
         entropy_cond(m,na,n-1)=-sum(cdata(m,n-1,j).*p_cond(na,n-1).*log(abs(cdata(m,n-1,j).*p_cond(na,n-1))));%������������
      end
         ES_cond(m,na,n-1)=-sum(entropy_node(m,na)-entropy_cond(m,na,n-1));
        %a(m,na,n-1)=abs(ES_cond(m,na,n-1))./5;
         %b(m,na)=ES_node(m,na)+abs(ES_cond(m,na,n-1));
         %c(m,na)=ES_node(m,na)+a(m,na,n-1);
         %ES_cond=abs(zscore(log(1.5+ES_cond)));
         ES_node(m,na)=ES_node(m,na)+abs(ES_cond(m,na,n-1))./5;
     end
end
end
%aa=entropy_cond(2,:,:);
ES_node_=abs(zscore(ES_node));
%ES_node_=ES_node/sum(ES_node);
%ES_node_=abs(mean(ES_node_));
%% %% re �㷨����
for m=1:psize(1)
for na=1:total_node_num%1:23
    for n=2:length(control_network{na})-1%2:6
        center=control_network{na}{1};
        center=str2num(center);
        nei=control_network{na}{n};
        ne=str2num(nei);
      for j=1:psize(3) %10
         rp_dis(m,na,j)=(abs(sum(abs(rdata(m,center,j)-rdata(m,n-1,j))))).^(1/2);
         %p_dis(n-1,j)=p_dis(n-1,j)./sum(p_dis(n-1,:));
      end
    end
end
end

rp_dis=abs(zscore(log(1.5+p_dis)));
rentropy_node=zeros(psize(1),1,psize(2));
rentropy_node=permute(rentropy_node,[1 3 2]) ;
for m=1:psize(1)
for na=1:total_node_num
     for j=1:psize(3)
     rp_node(m,na,j)=rp_dis(m,na,j)./sum(rp_dis(m,na,:)); 
     rentropy_node(m,na)=entropy_node(m,na)-rp_node(m,na,j).*rdata(m,na,j).*log(abs(rdata(m,na,j).*rp_node(m,na,j)));
end
end
end
max_legt_wegt=max(legt_wegt);
rp_cond=zeros(total_node_num,5);
rES_node=zeros(psize(1),psize(2));
for m=1:psize(1)
for na=1:total_node_num%23
    for n=2:length(control_network{na})-1%5
        center=control_network{na}{1};
        center=str2num(center);
        nei=control_network{na}{n};
        ne=str2num(nei);
      for j=1:ppsize(3) %10    
    
         rp_cond(na,n-1)=p_joint(na,n-1)./rp_node(na,j);
         rentropy_cond(m,na,n-1)=-sum(rdata(m,n-1,j).*rp_cond(na,n-1).*log(abs(rdata(m,n-1,j).*rp_cond(na,n-1))));%������������
      end
         rES_cond(m,na,n-1)=-sum(rentropy_node(m,na)-rentropy_cond(m,na,n-1));
         reES_node(m,na)=rES_node(m,na)+abs(rES_cond(m,na,n-1))./(legt_wegt(na)-1);
     end
end
end
reES_node_=abs(zscore(reES_node));

for j=1:23
for i=2:psize(1)+1 

    ES_node_1(i-1,j)=ES_node_(i,j);


    reES_node_1(i-1,j)=reES_node_(i-1,j);


end
end
a=ppsize(1)-psize(1);
for j=1:23
for i=psize(1)+2:ppsize(1) 

    ES_node_1(i-1,j)=ES_node_(i,j);


    reES_node_1(i-1,j)=reES_node_1(i-a,j);


end
end

DistEn_NFE0_1_mean=squeeze(mean(DistEn_NFE0_1,2));
c_DistEn_NFE0_1=squeeze(c_DistEn_NFE0_1);
for t=1:23
 for i=1:ppsize(1)-1 %1584-1
  SNIG(i,t)=abs(ES_node_1(i,t)-reES_node_1(i,t)); 
 end
end
SNIGmean=mean(SNIG,2);
xlswrite('C:\SNIGmean.xlsx',SNIGmean)
xlswrite('C:\SNIG.xlsx',SNIG)



